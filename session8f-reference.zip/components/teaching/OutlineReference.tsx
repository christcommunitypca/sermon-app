'use client'

import { useState } from 'react'
import { Plus } from 'lucide-react'
import type { VerseNote } from '@/types/database'
import type { PendingItem } from './TeachingWorkspace'

const CATEGORIES = [
  { key: 'word_study',            label: 'Word Study',     color: 'text-blue-600',    bg: 'bg-blue-50',    activeBg: 'bg-blue-600'    },
  { key: 'cross_refs',            label: 'Cross-refs',     color: 'text-purple-600',  bg: 'bg-purple-50',  activeBg: 'bg-purple-600'  },
  { key: 'practical',             label: 'Analogies',      color: 'text-amber-600',   bg: 'bg-amber-50',   activeBg: 'bg-amber-600'   },
  { key: 'theology_by_tradition', label: 'Tradition',      color: 'text-emerald-600', bg: 'bg-emerald-50', activeBg: 'bg-emerald-600' },
  { key: 'context',               label: 'Context',        color: 'text-orange-600',  bg: 'bg-orange-50',  activeBg: 'bg-orange-600'  },
  { key: 'application',           label: 'Application',    color: 'text-rose-600',    bg: 'bg-rose-50',    activeBg: 'bg-rose-600'    },
] as const

type CategoryKey = typeof CATEGORIES[number]['key']

type Insights = Record<string, Record<string, { title: string; content: string }[]>>

interface Props {
  insights:       Insights
  verseNotes:     Record<string, VerseNote[]>
  checkedItems:   Set<string>
  pendingItemId:  string | null
  onPendingItem:  (item: PendingItem) => void
}

export function OutlineReference({
  insights, verseNotes, checkedItems, pendingItemId, onPendingItem,
}: Props) {
  const [activeTab,     setActiveTab]     = useState<CategoryKey | 'notes'>('notes')
  const [hiddenVerses,  setHiddenVerses]  = useState<Set<string>>(new Set())

  // All verse refs that have any content (notes or insights)
  const allVerseRefs = Array.from(new Set([
    ...Object.keys(verseNotes).filter(ref => verseNotes[ref].some(n => n.content.trim())),
    ...Object.keys(insights),
  ])).sort()

  const hasNotes    = allVerseRefs.some(ref => verseNotes[ref]?.some(n => n.content.trim()))
  const hasInsights = Object.keys(insights).length > 0

  if (!hasNotes && !hasInsights) {
    return (
      <div className="px-4 py-8 text-center text-xs text-slate-300">
        Add notes and generate research in the Verse by Verse view
      </div>
    )
  }

  function toggleVerse(ref: string) {
    setHiddenVerses(prev => {
      const next = new Set(prev)
      next.has(ref) ? next.delete(ref) : next.add(ref)
      return next
    })
  }

  const visibleRefs = allVerseRefs.filter(ref => !hiddenVerses.has(ref))

  function queue(srcId: string, content: string, type: PendingItem['type'], kind: 'note' | 'research') {
    onPendingItem({ content, type, sourceKind: kind, sourceId: srcId })
  }

  // Count checked items per tab for badges
  function checkedCountForTab(tab: CategoryKey | 'notes') {
    if (tab === 'notes') {
      return Object.values(verseNotes).flat().filter(n => n.used_count > 0).length
    }
    let count = 0
    for (const [verseRef, cats] of Object.entries(insights)) {
      const items = cats[tab] ?? []
      items.forEach((_, i) => {
        if (checkedItems.has(`${verseRef}::${tab}::${i}`)) count++
      })
    }
    return count
  }

  // Build tab list — only show tabs that have content
  const visibleTabs: (CategoryKey | 'notes')[] = []
  if (hasNotes) visibleTabs.push('notes')
  for (const cat of CATEGORIES) {
    const hasAny = Object.values(insights).some(cats => (cats[cat.key]?.length ?? 0) > 0)
    if (hasAny) visibleTabs.push(cat.key)
  }

  // Ensure activeTab is valid
  const effectiveTab = visibleTabs.includes(activeTab) ? activeTab : (visibleTabs[0] ?? 'notes')

  return (
    <div className="flex flex-col gap-3 min-h-0">

      {/* ── Category tabs ──────────────────────────────────────────────────── */}
      <div className="flex flex-wrap gap-1">
        {visibleTabs.map(tab => {
          const cat    = CATEGORIES.find(c => c.key === tab)
          const isActive = tab === effectiveTab
          const used   = checkedCountForTab(tab)
          return (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                isActive
                  ? 'bg-slate-900 text-white'
                  : cat
                    ? `${cat.bg} ${cat.color} hover:opacity-80`
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab === 'notes' ? 'Notes' : cat?.label}
              {used > 0 && (
                <span className={`text-[10px] font-bold px-1 rounded-full ${
                  isActive ? 'bg-white/20 text-white' : 'bg-white/60 text-current'
                }`}>{used}</span>
              )}
            </button>
          )
        })}
      </div>

      {/* ── Verse filter pills ──────────────────────────────────────────────── */}
      {allVerseRefs.length > 1 && (
        <div className="flex flex-wrap gap-1">
          {allVerseRefs.map(ref => {
            const isVisible = !hiddenVerses.has(ref)
            // Extract just the verse number for brevity
            const label = ref.replace(/^.+\s/, '') // e.g. "Genesis 16:1" → "16:1"
            return (
              <button
                key={ref}
                onClick={() => toggleVerse(ref)}
                className={`px-2 py-0.5 rounded-md text-[11px] font-semibold transition-colors ${
                  isVisible
                    ? 'bg-slate-800 text-white'
                    : 'bg-slate-100 text-slate-400 hover:bg-slate-200'
                }`}
              >
                {label}
              </button>
            )
          })}
        </div>
      )}

      {/* ── Tab content ────────────────────────────────────────────────────── */}
      <div className="space-y-4 overflow-y-auto">

        {/* Notes tab */}
        {effectiveTab === 'notes' && (
          <div className="space-y-4">
            {visibleRefs.map(ref => {
              const notes = (verseNotes[ref] ?? []).filter(n => n.content.trim())
              if (!notes.length) return null
              return (
                <div key={ref}>
                  <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-2">{ref}</p>
                  <div className="space-y-1.5">
                    {notes.map(note => (
                      <div key={note.id} className="group relative flex items-start gap-2 pl-1">
                        <p className="flex-1 text-sm text-slate-600 leading-relaxed pr-8">
                          {note.content}
                        </p>
                        <div className="flex items-center gap-1 shrink-0 absolute right-0 top-0">
                          {note.used_count > 0 && (
                            <span className="text-[10px] font-semibold px-1.5 py-0.5 bg-violet-100 text-violet-500 rounded-full">
                              {note.used_count}×
                            </span>
                          )}
                          <button
                            onClick={() => queue(note.id, note.content, 'sub_point', 'note')}
                            className={`p-1.5 rounded-lg transition-all ${
                              pendingItemId === note.id
                                ? 'text-violet-600 bg-violet-100 opacity-100'
                                : 'text-slate-300 hover:text-slate-700 hover:bg-slate-100 opacity-0 group-hover:opacity-100'
                            }`}
                            title="Place in outline"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* Research category tabs */}
        {effectiveTab !== 'notes' && (() => {
          const cat = CATEGORIES.find(c => c.key === effectiveTab)!
          return (
            <div className="space-y-4">
              {visibleRefs.map(ref => {
                const items = (insights[ref]?.[effectiveTab] ?? [])
                if (!items.length) return null
                return (
                  <div key={ref}>
                    <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-2">{ref}</p>
                    <div className="space-y-2">
                      {items.map((item, i) => {
                        const itemKey  = `${ref}::${effectiveTab}::${i}`
                        const isChecked = checkedItems.has(itemKey)
                        const usedCount = isChecked ? 1 : 0  // proxy — checked = used in reference
                        return (
                          <div key={i} className={`group relative border-l-2 pl-3 transition-colors ${
                            isChecked ? `border-current ${cat.color}` : 'border-slate-100'
                          }`}>
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1 min-w-0">
                                {item.title && (
                                  effectiveTab === 'word_study'
                                    ? <WordStudyTitleInline title={item.title} />
                                    : <span className="text-xs font-semibold text-slate-700 block mb-0.5">{item.title}</span>
                                )}
                                <p className="text-sm text-slate-600 leading-relaxed">{item.content}</p>
                              </div>
                              <div className="flex items-center gap-1 shrink-0 ml-2">
                                {isChecked && (
                                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${cat.bg} ${cat.color}`}>
                                    ✓
                                  </span>
                                )}
                                <button
                                  onClick={() => {
                                    const type: PendingItem['type'] =
                                      effectiveTab === 'application' ? 'application'
                                      : effectiveTab === 'practical' ? 'illustration'
                                      : 'sub_point'
                                    const content = item.title ? `${item.title} — ${item.content}` : item.content
                                    queue(`${ref}-${effectiveTab}-${i}`, content, type, 'research')
                                  }}
                                  className={`p-1.5 rounded-lg transition-all opacity-0 group-hover:opacity-100 ${
                                    pendingItemId === `${ref}-${effectiveTab}-${i}`
                                      ? 'text-violet-600 bg-violet-100 opacity-100'
                                      : 'text-slate-300 hover:text-slate-700 hover:bg-slate-100'
                                  }`}
                                  title="Place in outline"
                                >
                                  <Plus className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )
              })}
            </div>
          )
        })()}
      </div>
    </div>
  )
}

function WordStudyTitleInline({ title }: { title: string }) {
  const match = title.match(/^(.+?)\s+\((.+)\)$/)
  if (!match) return <span className="text-xs font-semibold text-slate-700">{title}</span>
  const [, original, transliteration] = match
  return (
    <span className="flex items-baseline gap-1.5 mb-0.5">
      <span className="text-sm font-bold text-slate-800">{original}</span>
      <span className="text-xs text-slate-500">{transliteration}</span>
    </span>
  )
}
