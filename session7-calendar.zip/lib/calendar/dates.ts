/**
 * Church Calendar Date Utilities
 * Computes dates for recurring liturgical/church events for a given year.
 */

// ── Easter (Anonymous Gregorian algorithm) ─────────────────────────────────────
// Returns Easter Sunday date for the given year.
export function easterDate(year: number): Date {
  const a = year % 19
  const b = Math.floor(year / 100)
  const c = year % 100
  const d = Math.floor(b / 4)
  const e = b % 4
  const f = Math.floor((b + 8) / 25)
  const g = Math.floor((b - f + 1) / 3)
  const h = (19 * a + b - d - g + 15) % 30
  const i = Math.floor(c / 4)
  const k = c % 4
  const l = (32 + 2 * e + 2 * i - h - k) % 7
  const m = Math.floor((a + 11 * h + 22 * l) / 451)
  const month = Math.floor((h + l - 7 * m + 114) / 31) - 1  // 0-indexed
  const day   = ((h + l - 7 * m + 114) % 31) + 1
  return new Date(year, month, day)
}

// ── Palm Sunday = Easter - 7 days ─────────────────────────────────────────────
export function palmSundayDate(year: number): Date {
  const d = easterDate(year)
  d.setDate(d.getDate() - 7)
  return d
}

// ── Advent Start = 4th Sunday before Christmas ────────────────────────────────
export function adventStartDate(year: number): Date {
  // Christmas is Dec 25
  const christmas = new Date(year, 11, 25)
  // Find the Sunday on or before Dec 25, then go back 3 more Sundays = 4th Sunday before
  const christmasDay = christmas.getDay() // 0 = Sunday
  // Days to previous Sunday
  const daysToSunday = christmasDay === 0 ? 0 : christmasDay
  const sundayBeforeChristmas = new Date(year, 11, 25 - daysToSunday)
  // Advent starts 3 Sundays before that Sunday = 21 days back
  const adventStart = new Date(sundayBeforeChristmas)
  adventStart.setDate(adventStart.getDate() - 21)
  return adventStart
}

// ── Christmas = Dec 25 ─────────────────────────────────────────────────────────
export function christmasDate(year: number): Date {
  return new Date(year, 11, 25)
}

// ── Reformation Sunday = last Sunday of October ────────────────────────────────
export function reformationSundayDate(year: number): Date {
  // Last day of October
  const lastOct = new Date(year, 10, 0) // Nov 0 = Oct 31
  const dow = lastOct.getDay()
  const daysBack = dow === 0 ? 0 : dow
  const lastSunday = new Date(year, 9, 31 - daysBack)
  return lastSunday
}

// ── Key → compute function map ─────────────────────────────────────────────────
export const RECURRENCE_COMPUTERS: Record<string, (year: number) => Date> = {
  easter:             easterDate,
  palm_sunday:        palmSundayDate,
  advent_start:       adventStartDate,
  christmas:          christmasDate,
  reformation_sunday: reformationSundayDate,
}

export type RecurrenceKey = keyof typeof RECURRENCE_COMPUTERS

// ── Compute date for a given recurrence key and year ──────────────────────────
export function computeRecurringDate(key: string, year: number): Date | null {
  const fn = RECURRENCE_COMPUTERS[key]
  return fn ? fn(year) : null
}

// ── Compute all built-in dates for a year range ───────────────────────────────
export function computeBuiltInDates(
  fromYear: number,
  toYear: number
): { key: string; name: string; date: Date }[] {
  const results: { key: string; name: string; date: Date }[] = []
  const NAMES: Record<string, string> = {
    easter:             'Easter Sunday',
    palm_sunday:        'Palm Sunday',
    advent_start:       'Advent Sunday',
    christmas:          'Christmas',
    reformation_sunday: 'Reformation Sunday',
  }
  for (let year = fromYear; year <= toYear; year++) {
    for (const [key, fn] of Object.entries(RECURRENCE_COMPUTERS)) {
      results.push({ key, name: NAMES[key] ?? key, date: fn(year) })
    }
  }
  return results
}

// ── ISO date string helper ────────────────────────────────────────────────────
export function toISODate(d: Date): string {
  return d.toISOString().split('T')[0]
}

// ── Format for display ────────────────────────────────────────────────────────
export function formatEventDate(dateStr: string): string {
  return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-US', {
    weekday: 'short', month: 'short', day: 'numeric', year: 'numeric',
  })
}
