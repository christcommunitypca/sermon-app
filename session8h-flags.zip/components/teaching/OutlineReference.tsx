'use client'

import { useState } from 'react'
import { Plus } from 'lucide-react'
import type { VerseNote } from '@/types/database'
import type { PendingItem } from './TeachingWorkspace'
import { incrementInsightUsedCountAction } from '@/app/actions/verse-study'

const CATEGORIES = [
  { key: 'word_study',            label: 'Word Study'  },
  { key: 'cross_refs',            label: 'Cross-refs'  },
  { key: 'practical',             label: 'Analogies'   },
  { key: 'theology_by_tradition', label: 'Tradition'   },
  { key: 'context',               label: 'Context'     },
  { key: 'application',           label: 'Application' },
] as const

type CategoryKey = typeof CATEGORIES[number]['key']
type InsightItem = { title: string; content: string; is_flagged?: boolean; used_count?: number }
type Insights    = Record<string, Record<string, InsightItem[]>>

interface Props {
  insights:      Insights
  verseNotes:    Record<string, VerseNote[]>
  hiddenVerses:  Set<string>
  sessionId:     string
  pendingItemId: string | null
  onPendingItem: (item: PendingItem) => void
  onInsightsChange: (insights: Insights) => void
}

export function OutlineReference({
  insights, verseNotes, hiddenVerses, sessionId,
  pendingItemId, onPendingItem, onInsightsChange,
}: Props) {
  const [activeTab,  setActiveTab]  = useState<CategoryKey | 'notes'>('notes')
  const [flagFilter, setFlagFilter] = useState<'all' | 'flagged' | 'unflagged'>('all')
  const [usedFilter, setUsedFilter] = useState<'all' | 'used' | 'unused'>('all')

  const allVerseRefs = Array.from(new Set([
    ...Object.keys(verseNotes).filter(r => verseNotes[r].some(n => n.content.trim())),
    ...Object.keys(insights),
  ])).sort()

  const hasNotes    = allVerseRefs.some(r => verseNotes[r]?.some(n => n.content.trim()))
  const hasInsights = Object.keys(insights).length > 0

  if (!hasNotes && !hasInsights) {
    return (
      <div className="px-4 py-8 text-center text-xs text-slate-300">
        Add notes and generate research in the Verse by Verse view
      </div>
    )
  }

  const visibleRefs = allVerseRefs.filter(r => !hiddenVerses.has(r))

  function queue(srcId: string, content: string, type: PendingItem['type'], kind: 'note' | 'research') {
    onPendingItem({ content, type, sourceKind: kind, sourceId: srcId })
  }

  function incrementItemUsedCount(verseRef: string, category: string, index: number) {
    onInsightsChange({
      ...insights,
      [verseRef]: {
        ...insights[verseRef],
        [category]: (insights[verseRef]?.[category] ?? []).map((it, i) =>
          i === index ? { ...it, used_count: (it.used_count ?? 0) + 1 } : it
        ),
      },
    })
    incrementInsightUsedCountAction(sessionId, verseRef, category, index).catch(() => null)
  }

  // Build visible tabs (only categories with content)
  const visibleTabs: (CategoryKey | 'notes')[] = []
  if (hasNotes) visibleTabs.push('notes')
  for (const cat of CATEGORIES) {
    if (Object.values(insights).some(cats => (cats[cat.key]?.length ?? 0) > 0)) visibleTabs.push(cat.key)
  }
  const effectiveTab = visibleTabs.includes(activeTab) ? activeTab : (visibleTabs[0] ?? 'notes')

  // Count used items per tab for badge
  function usedCount(tab: CategoryKey | 'notes') {
    if (tab === 'notes') return Object.values(verseNotes).flat().filter(n => n.used_count > 0).length
    let n = 0
    for (const cats of Object.values(insights)) {
      for (const item of cats[tab] ?? []) {
        if ((item.used_count ?? 0) > 0) n++
      }
    }
    return n
  }

  return (
    <div className="flex flex-col gap-2 min-h-0">

      {/* ── Tabs — VBV gray/black style ─────────────────────────────────────── */}
      <div className="flex flex-wrap gap-1.5">
        {visibleTabs.map(tab => {
          const cat      = CATEGORIES.find(c => c.key === tab)
          const isActive = tab === effectiveTab
          const used     = usedCount(tab)
          return (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                isActive
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-500 hover:bg-slate-200 hover:text-slate-700'
              }`}
            >
              {tab === 'notes' ? 'Notes' : cat?.label}
              {used > 0 && (
                <span className={`ml-1 text-[10px] font-bold ${isActive ? 'opacity-70' : 'opacity-60'}`}>
                  {used}
                </span>
              )}
            </button>
          )
        })}
      </div>

      {/* ── Filters ───────────────────────────────────────────────────────── */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="flex items-center gap-0.5 bg-slate-100 rounded-lg p-0.5">
          {(['all', 'flagged', 'unflagged'] as const).map(f => (
            <button key={f} onClick={() => setFlagFilter(f)}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                flagFilter === f ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-400 hover:text-slate-600'
              }`}>
              {f === 'all' ? 'All' : f === 'flagged' ? '✓ Flagged' : 'Unflagged'}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-0.5 bg-slate-100 rounded-lg p-0.5">
          {(['all', 'unused', 'used'] as const).map(f => (
            <button key={f} onClick={() => setUsedFilter(f)}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                usedFilter === f ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-400 hover:text-slate-600'
              }`}>
              {f === 'all' ? 'All' : f === 'used' ? 'Used' : 'Unused'}
            </button>
          ))}
        </div>
      </div>

      {/* ── Content ───────────────────────────────────────────────────────── */}
      <div className="space-y-4 overflow-y-auto pb-4">

        {/* Notes tab */}
        {effectiveTab === 'notes' && visibleRefs.map(ref => {
          const notes = (verseNotes[ref] ?? []).filter(n => {
            if (!n.content.trim()) return false
            if (flagFilter === 'flagged'   && n.used_count === 0) return false
            if (flagFilter === 'unflagged' && n.used_count  > 0) return false
            if (usedFilter === 'used'      && n.used_count === 0) return false
            if (usedFilter === 'unused'    && n.used_count  > 0) return false
            return true
          })
          if (!notes.length) return null
          return (
            <div key={ref}>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-2">{ref}</p>
              <div className="space-y-1.5">
                {notes.map(note => (
                  <div key={note.id} className="group relative flex items-start gap-2 rounded-lg px-2 py-1.5 hover:bg-slate-50">
                    <p className="flex-1 text-sm text-slate-600 leading-relaxed pr-10">{note.content}</p>
                    <div className="flex items-center gap-1 shrink-0 absolute right-1 top-1.5">
                      {note.used_count > 0 && (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 bg-violet-100 text-violet-500 rounded-full">
                          {note.used_count}×
                        </span>
                      )}
                      <button
                        onClick={() => queue(note.id, note.content, 'sub_point', 'note')}
                        className={`p-1.5 rounded-lg transition-all ${
                          pendingItemId === note.id
                            ? 'text-violet-600 bg-violet-100 opacity-100'
                            : 'text-slate-300 hover:text-slate-700 hover:bg-slate-100 opacity-0 group-hover:opacity-100'
                        }`}
                        title="Place in outline"
                      ><Plus className="w-3.5 h-3.5" /></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )
        })}

        {/* Research category tabs */}
        {effectiveTab !== 'notes' && (() => {
          return visibleRefs.map(ref => {
            const allItems = insights[ref]?.[effectiveTab] ?? []
            const items = allItems.filter(item => {
              if (flagFilter === 'flagged'   && !item.is_flagged) return false
              if (flagFilter === 'unflagged' &&  item.is_flagged) return false
              if (usedFilter === 'used'      && !(item.used_count ?? 0)) return false
              if (usedFilter === 'unused'    &&  (item.used_count ?? 0) > 0) return false
              return true
            })
            if (!items.length) return null
            return (
              <div key={ref}>
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-2">{ref}</p>
                <div className="space-y-2">
                  {items.map((item) => {
                    const origIdx  = allItems.indexOf(item)
                    const pendKey  = `${ref}-${effectiveTab}-${origIdx}`
                    const usedCnt  = item.used_count ?? 0
                    return (
                      <div key={origIdx} className={`group relative border-l-2 pl-3 rounded-r-lg py-1 transition-colors ${
                        item.is_flagged ? 'border-slate-400 bg-slate-50' : 'border-slate-100 hover:border-slate-200'
                      }`}>
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            {item.title && (
                              effectiveTab === 'word_study'
                                ? <WordStudyTitle title={item.title} />
                                : <span className="text-xs font-semibold text-slate-700 block mb-0.5">{item.title}</span>
                            )}
                            <p className="text-sm text-slate-600 leading-relaxed">{item.content}</p>
                          </div>
                          <div className="flex items-center gap-1 shrink-0 ml-2">
                            {item.is_flagged && (
                              <span className="text-[11px] font-bold px-1.5 py-0.5 rounded-full bg-slate-200 text-slate-600">✓</span>
                            )}
                            {usedCnt > 0 && (
                              <span className="text-[10px] font-bold px-1.5 py-0.5 bg-violet-100 text-violet-500 rounded-full">
                                {usedCnt}×
                              </span>
                            )}
                            <button
                              onClick={() => {
                                const type: PendingItem['type'] =
                                  effectiveTab === 'application' ? 'application'
                                  : effectiveTab === 'practical' ? 'illustration'
                                  : 'sub_point'
                                const content = item.title ? `${item.title} — ${item.content}` : item.content
                                queue(pendKey, content, type, 'research')
                                incrementItemUsedCount(ref, effectiveTab, origIdx)
                              }}
                              className={`p-1.5 rounded-lg transition-all opacity-0 group-hover:opacity-100 ${
                                pendingItemId === pendKey
                                  ? 'text-violet-600 bg-violet-100 opacity-100'
                                  : 'text-slate-300 hover:text-slate-700 hover:bg-slate-100'
                              }`}
                              title="Place in outline"
                            ><Plus className="w-3.5 h-3.5" /></button>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            )
          })
        })()}
      </div>
    </div>
  )
}

function WordStudyTitle({ title }: { title: string }) {
  const match = title.match(/^(.+?)\s+\((.+)\)$/)
  if (!match) return <span className="text-xs font-semibold text-slate-700 block mb-0.5">{title}</span>
  const [, original, transliteration] = match
  return (
    <span className="flex items-baseline gap-1.5 mb-0.5">
      <span className="text-sm font-bold text-slate-800">{original}</span>
      <span className="text-xs text-slate-500 italic">{transliteration}</span>
    </span>
  )
}
