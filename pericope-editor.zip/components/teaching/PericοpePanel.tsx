'use client'
// ── components/teaching/PericοpePanel.tsx ────────────────────────────────────
// Section-by-section research panel for narrative passages.
// Mirrors VBV panel layout but groups by pericope instead of individual verse.

import { useState, useCallback } from 'react'
import {
  ChevronDown, ChevronRight, Sparkles, Loader2, Check,
  Plus, X, AlertCircle, BookOpen,
} from 'lucide-react'
import type { VerseData, SectionHeader } from '@/lib/esv'
import { generatePericοpeInsightsAction, savePericοpeSectionsAction } from '@/app/actions/verse-study'

// ── Types ─────────────────────────────────────────────────────────────────────

type InsightItem = { title: string; content: string; is_flagged?: boolean; used_count?: number }
type Insights    = Record<string, Record<string, InsightItem[]>>  // sectionLabel → category → items

const CATEGORIES = [
  { key: 'word_study',           label: 'Words'      },
  { key: 'context',              label: 'Context'    },
  { key: 'cross_refs',           label: 'Cross-refs' },
  { key: 'theology_by_tradition',label: 'Theology'   },
  { key: 'practical',            label: 'Illustr.'   },
  { key: 'application',          label: 'Apply'      },
  { key: 'quotes',               label: 'Quotes'     },
] as const
type CategoryKey = typeof CATEGORIES[number]['key']

interface Props {
  sessionId:   string
  churchId:    string
  verses:      VerseData[]
  sections:    SectionHeader[]       // from ESV API or user-defined
  hasHeaders:  boolean               // false = ESV returned no headers
  insights:    Insights
  onInsightsChange: (i: Insights) => void
  onSectionsChange: (s: SectionHeader[]) => void
  pending:     { id: string; content: string; type: string; source: string } | null
  onItemPlaced: (item: { id: string; content: string; type: string; source: string }) => void
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function versesForSection(verses: VerseData[], sections: SectionHeader[], idx: number): VerseData[] {
  const start = sections[idx].startVerse
  // Explicit endVerse takes priority; otherwise run to next section start
  const explicitEnd = sections[idx].endVerse
  const impliedEnd  = idx + 1 < sections.length ? sections[idx + 1].startVerse : null

  const startIdx = verses.findIndex(v => v.verse_ref === start)
  if (startIdx === -1) return []

  if (explicitEnd) {
    const endIdx = verses.findIndex(v => v.verse_ref === explicitEnd)
    return endIdx >= startIdx ? verses.slice(startIdx, endIdx + 1) : verses.slice(startIdx, startIdx + 1)
  }

  if (impliedEnd) {
    const endIdx = verses.findIndex(v => v.verse_ref === impliedEnd)
    return endIdx > startIdx ? verses.slice(startIdx, endIdx) : verses.slice(startIdx)
  }

  return verses.slice(startIdx)
}

function verseRangeLabel(sectionVerses: VerseData[]): string {
  if (!sectionVerses.length) return ''
  if (sectionVerses.length === 1) return sectionVerses[0].verse_ref
  const first = sectionVerses[0].verse_ref
  const last  = sectionVerses[sectionVerses.length - 1].verse_ref
  // Compact: "Mark 11:1-10"
  const firstParts = first.match(/^(.+)\s(\d+):(\d+)$/)
  const lastParts  = last.match(/^(.+)\s(\d+):(\d+)$/)
  if (firstParts && lastParts && firstParts[1] === lastParts[1] && firstParts[2] === lastParts[2]) {
    return `${firstParts[1]} ${firstParts[2]}:${firstParts[3]}–${lastParts[3]}`
  }
  return `${first}–${last}`
}

// ── Main component ────────────────────────────────────────────────────────────

export function PericοpePanel({
  sessionId, churchId, verses, sections, hasHeaders,
  insights, onInsightsChange, onSectionsChange,
  pending, onItemPlaced,
}: Props) {

  const [expanded,    setExpanded]    = useState<Record<number, boolean>>({0: true})
  const [activeTab,   setActiveTab]   = useState<Record<number, CategoryKey>>({})
  const [generating,  setGenerating]  = useState<Record<number, boolean>>({})
  const [errors,      setErrors]      = useState<Record<number, string>>({})
  const [showText,    setShowText]    = useState<Record<number, boolean>>({})

  // Manual section editor state
  const [editMode,    setEditMode]    = useState(false)
  const [draftSects,  setDraftSects]  = useState<SectionHeader[]>(sections)
  const [savingEdit,  setSavingEdit]  = useState(false)

  const toggleSection = useCallback((i: number) => {
    setExpanded(p => ({ ...p, [i]: !p[i] }))
  }, [])

  async function handleGenerate(idx: number) {
    const sectionVerses = versesForSection(verses, sections, idx)
    if (!sectionVerses.length) return

    setGenerating(p => ({ ...p, [idx]: true }))
    setErrors(p => ({ ...p, [idx]: '' }))

    const result = await generatePericοpeInsightsAction(sessionId, churchId, {
      label:  sections[idx].label,
      verses: sectionVerses,
    })

    setGenerating(p => ({ ...p, [idx]: false }))

    if (result.error) {
      setErrors(p => ({ ...p, [idx]: result.error! }))
      return
    }

    // Insights will be reloaded via parent — optimistically mark section as done
    // by auto-expanding and switching to first category
    setExpanded(p => ({ ...p, [idx]: true }))
    setActiveTab(p => ({ ...p, [idx]: 'context' }))
  }

  function getSectionInsights(label: string, cat: CategoryKey): InsightItem[] {
    return insights[label]?.[cat] ?? []
  }

  function hasSectionResearch(label: string): boolean {
    return Object.values(insights[label] ?? {}).some(items => items.length > 0)
  }

  async function saveEditedSections() {
    setSavingEdit(true)
    await savePericοpeSectionsAction(sessionId, draftSects)
    onSectionsChange(draftSects)
    setEditMode(false)
    setSavingEdit(false)
  }

  function addDraftSection() {
    setDraftSects(p => [...p, { label: '', startVerse: '' }])
  }

  function removeDraftSection(i: number) {
    setDraftSects(p => p.filter((_, idx) => idx !== i))
  }

  // ── Manual section editor (shown when no headers or edit mode) ─────────────
  if (!hasHeaders && sections.length === 0) {
    return (
      <ManualSectionEditor
        verses={verses}
        onSave={async (sects) => {
          await savePericοpeSectionsAction(sessionId, sects)
          onSectionsChange(sects)
        }}
      />
    )
  }

  return (
    <div className="flex flex-col gap-3 min-h-0">

      {/* Header row */}
      <div className="flex items-center justify-between">
        <span className="text-xs text-slate-400 font-medium">{sections.length} sections</span>
        <button
          onClick={() => { setEditMode(v => !v); setDraftSects(sections) }}
          className="text-[11px] text-slate-400 hover:text-slate-700 underline"
        >
          {editMode ? 'Cancel' : 'Edit sections'}
        </button>
      </div>

      {/* Section edit mode */}
      {editMode && (
        <div className="border border-slate-200 rounded-xl p-3 space-y-2 bg-slate-50">
          <p className="text-xs text-slate-500 mb-2">Drag to reorder · edit labels · adjust start verses</p>
          {draftSects.map((s, i) => (
            <div key={i} className="flex items-center gap-2">
              <input
                className="flex-1 text-xs border border-slate-200 rounded-lg px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-violet-300"
                placeholder="Section label"
                value={s.label}
                onChange={e => setDraftSects(p => p.map((x, xi) => xi === i ? { ...x, label: e.target.value } : x))}
              />
              <input
                className="w-28 text-xs border border-slate-200 rounded-lg px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-violet-300"
                placeholder="Start verse"
                value={s.startVerse}
                onChange={e => setDraftSects(p => p.map((x, xi) => xi === i ? { ...x, startVerse: e.target.value } : x))}
              />
              <button onClick={() => removeDraftSection(i)} className="text-slate-300 hover:text-red-400 transition-colors">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
          <div className="flex gap-2 pt-1">
            <button onClick={addDraftSection}
              className="text-xs text-violet-600 hover:text-violet-800 flex items-center gap-1">
              <Plus className="w-3 h-3" />Add section
            </button>
            <button
              onClick={saveEditedSections}
              disabled={savingEdit}
              className="ml-auto text-xs bg-slate-900 text-white px-3 py-1.5 rounded-lg hover:bg-slate-700 disabled:opacity-40 flex items-center gap-1"
            >
              {savingEdit ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />}
              Save
            </button>
          </div>
        </div>
      )}

      {/* Section accordion */}
      <div className="flex flex-col gap-2 overflow-y-auto min-h-0">
        {sections.map((section, idx) => {
          const sectionVerses  = versesForSection(verses, sections, idx)
          const rangeLabel     = verseRangeLabel(sectionVerses)
          const isExpanded     = expanded[idx] ?? false
          const cat            = activeTab[idx] ?? 'context'
          const isGenerating   = generating[idx] ?? false
          const hasResearch    = hasSectionResearch(section.label)
          const items          = getSectionInsights(section.label, cat)
          const errorMsg       = errors[idx]

          return (
            <div key={idx} className="border border-slate-200 rounded-xl overflow-hidden">

              {/* Section header row */}
              <div
                className="flex items-center gap-2 px-3 py-2.5 bg-slate-50 cursor-pointer hover:bg-slate-100 transition-colors"
                onClick={() => toggleSection(idx)}
              >
                {isExpanded
                  ? <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  : <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />}
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-slate-800 truncate">{section.label}</p>
                  <p className="text-[11px] text-slate-400">{rangeLabel}</p>
                </div>
                {hasResearch && (
                  <span className="w-1.5 h-1.5 rounded-full bg-violet-400 shrink-0" title="Research generated" />
                )}
                <button
                  onClick={e => { e.stopPropagation(); handleGenerate(idx) }}
                  disabled={isGenerating}
                  className={`flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-medium transition-colors shrink-0 ${
                    hasResearch
                      ? 'text-slate-400 hover:text-violet-600 hover:bg-violet-50'
                      : 'bg-violet-50 text-violet-600 hover:bg-violet-100'
                  }`}
                >
                  {isGenerating
                    ? <Loader2 className="w-3 h-3 animate-spin" />
                    : <Sparkles className="w-3 h-3" />}
                  {isGenerating ? 'Generating…' : hasResearch ? 'Regen' : 'Generate'}
                </button>
              </div>

              {/* Expanded body */}
              {isExpanded && (
                <div className="px-3 pb-3 pt-2">

                  {/* Verse text toggle */}
                  <button
                    onClick={() => setShowText(p => ({ ...p, [idx]: !p[idx] }))}
                    className="text-[11px] text-slate-400 hover:text-slate-600 flex items-center gap-1 mb-2"
                  >
                    <BookOpen className="w-3 h-3" />
                    {showText[idx] ? 'Hide text' : 'Show passage text'}
                  </button>

                  {showText[idx] && (
                    <div className="mb-3 px-3 py-2 bg-amber-50 border border-amber-100 rounded-lg">
                      {sectionVerses.map(v => (
                        <p key={v.verse_ref} className="text-xs text-slate-700 leading-relaxed">
                          <span className="text-[10px] font-bold text-slate-400 mr-1">{v.verse_ref}</span>
                          {v.text}
                        </p>
                      ))}
                    </div>
                  )}

                  {errorMsg && (
                    <div className="flex items-center gap-2 px-2 py-1.5 bg-red-50 border border-red-200 rounded-lg mb-2 text-xs text-red-700">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      {errorMsg}
                    </div>
                  )}

                  {!hasResearch && !isGenerating && (
                    <p className="text-xs text-slate-400 text-center py-4">
                      Click Generate to research this section
                    </p>
                  )}

                  {hasResearch && (
                    <>
                      {/* Category tabs */}
                      <div className="flex items-center gap-1 flex-wrap mb-3">
                        {CATEGORIES.map(c => {
                          const catItems = getSectionInsights(section.label, c.key)
                          const isActive = cat === c.key
                          return (
                            <button
                              key={c.key}
                              onClick={() => setActiveTab(p => ({ ...p, [idx]: c.key }))}
                              className={`px-2 py-0.5 rounded-lg text-[11px] font-medium transition-colors ${
                                isActive
                                  ? 'bg-slate-900 text-white'
                                  : catItems.length
                                    ? 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                                    : 'text-slate-300'
                              }`}
                            >
                              {c.label}
                              {catItems.length > 0 && (
                                <span className={`ml-1 text-[10px] ${isActive ? 'text-slate-300' : 'text-slate-400'}`}>
                                  {catItems.length}
                                </span>
                              )}
                            </button>
                          )
                        })}
                      </div>

                      {/* Research items */}
                      <div className="flex flex-col gap-2">
                        {items.length === 0 ? (
                          <p className="text-xs text-slate-300 text-center py-2">No items in this category</p>
                        ) : items.map((item, i) => (
                          <ResearchItem
                            key={i}
                            item={item}
                            sectionLabel={section.label}
                            category={cat}
                            pending={pending}
                            onPlace={() => {
                              const content = item.title ? `${item.title} — ${item.content}` : item.content
                              onItemPlaced({
                                id: `${section.label}-${cat}-${i}`,
                                content,
                                type: cat === 'application' ? 'application' : cat === 'practical' ? 'illustration' : 'sub_point',
                                source: 'research',
                              })
                            }}
                          />
                        ))}
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── ResearchItem ──────────────────────────────────────────────────────────────

function ResearchItem({
  item, pending, onPlace,
}: {
  item:         InsightItem
  sectionLabel: string
  category:     string
  pending:      Props['pending']
  onPlace:      () => void
}) {
  const isPending = pending?.content?.startsWith(item.title || item.content.slice(0, 20))

  return (
    <div className={`group border-l-2 pl-3 rounded-r-lg py-1 transition-colors ${
      item.is_flagged ? 'border-slate-400 bg-slate-50' : 'border-slate-100 hover:border-slate-200'
    }`}>
      <div className="flex items-center gap-0.5 shrink-0 mb-1">
        <button
          onClick={onPlace}
          className={`w-5 h-5 flex items-center justify-center rounded transition-all ${
            isPending ? 'text-violet-600 bg-violet-100' : 'text-slate-300 hover:text-slate-600 hover:bg-slate-100'
          }`}
          title="Place in outline"
        >
          <Plus className="w-3 h-3" />
        </button>
        <span className={`w-5 h-5 flex items-center justify-center rounded text-[10px] font-bold ${
          item.is_flagged ? 'bg-slate-200 text-slate-600' : ''
        }`}>{item.is_flagged ? '✓' : ''}</span>
        <span className={`w-5 h-5 flex items-center justify-center rounded text-[10px] font-bold ${
          (item.used_count ?? 0) > 0 ? 'bg-violet-100 text-violet-500' : ''
        }`}>{(item.used_count ?? 0) > 0 ? `${item.used_count}×` : ''}</span>
      </div>
      {item.title && (
        <p className="text-xs font-semibold text-slate-700 mb-0.5">{item.title}</p>
      )}
      <p className="text-sm text-slate-600 leading-relaxed">{item.content}</p>
    </div>
  )
}

// ── ManualSectionEditor ───────────────────────────────────────────────────────
// Shown when ESV returns no section headers — user defines pericope boundaries.

interface DraftSection {
  id:         number
  label:      string
  startVerse: string
  endVerse:   string
}

function ManualSectionEditor({
  verses,
  onSave,
}: {
  verses:  VerseData[]
  onSave:  (sections: SectionHeader[]) => Promise<void>
}) {
  const [sections, setSections] = useState<DraftSection[]>([])
  const [saving,   setSaving]   = useState(false)
  const [nextId,   setNextId]   = useState(1)

  // Parse verse_ref into { book, chapter, verse }
  function parseRef(ref: string) {
    const m = ref.match(/^(.+)\s(\d+):(\d+)$/)
    if (!m) return null
    return { book: m[1], chapter: parseInt(m[2]), verse: parseInt(m[3]) }
  }

  // All unique chapters in the passage
  const chapters = [...new Set(verses.map(v => parseRef(v.verse_ref)?.chapter).filter(Boolean))] as number[]
  const multiChapter = chapters.length > 1
  const bookName = parseRef(verses[0]?.verse_ref)?.book ?? ''

  // Verses grouped by chapter
  function versesForChapter(ch: number) {
    return verses.filter(v => parseRef(v.verse_ref)?.chapter === ch)
  }

  function firstVerseRef() { return verses[0]?.verse_ref ?? '' }

  function addSection() {
    const last = sections[sections.length - 1]
    let defaultStart = ''

    if (last?.endVerse) {
      // Start after the last section's end
      const lastEndIdx = verses.findIndex(v => v.verse_ref === last.endVerse)
      defaultStart = verses[lastEndIdx + 1]?.verse_ref ?? ''
    } else if (sections.length === 0) {
      defaultStart = firstVerseRef()
    }
    // If last section has no end, don't default — user must choose

    const id = nextId
    setNextId(n => n + 1)
    setSections(p => [...p, { id, label: '', startVerse: defaultStart, endVerse: '' }])
  }

  function removeSection(id: number) {
    setSections(p => p.filter(s => s.id !== id))
  }

  function updateSection(id: number, field: keyof DraftSection, value: string) {
    setSections(p => p.map(s => s.id === id ? { ...s, [field]: value } : s))
  }

  // Detect overlaps between sections
  function getOverlaps(): Set<number> {
    const overlapping = new Set<number>()
    for (let i = 0; i < sections.length; i++) {
      for (let j = i + 1; j < sections.length; j++) {
        const a = sections[i], b = sections[j]
        if (!a.startVerse || !b.startVerse) continue
        const aStartIdx = verses.findIndex(v => v.verse_ref === a.startVerse)
        const aEndIdx   = a.endVerse ? verses.findIndex(v => v.verse_ref === a.endVerse) : verses.length - 1
        const bStartIdx = verses.findIndex(v => v.verse_ref === b.startVerse)
        const bEndIdx   = b.endVerse ? verses.findIndex(v => v.verse_ref === b.endVerse) : verses.length - 1
        if (aStartIdx <= bEndIdx && bStartIdx <= aEndIdx) {
          overlapping.add(a.id)
          overlapping.add(b.id)
        }
      }
    }
    return overlapping
  }

  // Verses not covered by any section
  function uncoveredCount(): number {
    const covered = new Set<string>()
    for (const s of sections) {
      if (!s.startVerse) continue
      const startIdx = verses.findIndex(v => v.verse_ref === s.startVerse)
      const endIdx   = s.endVerse ? verses.findIndex(v => v.verse_ref === s.endVerse) : -1
      const end      = endIdx >= 0 ? endIdx : startIdx
      for (let i = startIdx; i <= end && i < verses.length; i++) {
        if (i >= 0) covered.add(verses[i].verse_ref)
      }
    }
    return verses.length - covered.size
  }

  async function handleSave() {
    const valid = sections.filter(s => s.label.trim() && s.startVerse)
    if (!valid.length) return
    setSaving(true)
    await onSave(valid.map(s => ({
      label:      s.label.trim(),
      startVerse: s.startVerse,
      endVerse:   s.endVerse || undefined,
    })))
    setSaving(false)
  }

  // ── Verse picker: chapter dropdown (if multi-chapter) + verse number ────────
  function VersePicker({ value, onChange, label }: {
    value: string; onChange: (v: string) => void; label: string
  }) {
    const parsed     = parseRef(value)
    const selChapter = parsed?.chapter ?? chapters[0] ?? 1
    const chVerses   = versesForChapter(selChapter)

    if (!multiChapter) {
      // Single chapter — just verse number dropdown
      return (
        <div className="flex flex-col gap-0.5 min-w-[90px]">
          <span className="text-[10px] text-slate-400 font-medium">{label}</span>
          <select
            value={value}
            onChange={e => onChange(e.target.value)}
            className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-violet-300 bg-white"
          >
            {!value && <option value="">—</option>}
            {verses.map(v => {
              const p = parseRef(v.verse_ref)
              return <option key={v.verse_ref} value={v.verse_ref}>v.{p?.verse}</option>
            })}
          </select>
        </div>
      )
    }

    // Multi-chapter — chapter + verse dropdowns
    return (
      <div className="flex flex-col gap-0.5">
        <span className="text-[10px] text-slate-400 font-medium">{label}</span>
        <div className="flex items-center gap-1">
          <select
            value={selChapter}
            onChange={e => {
              const ch = parseInt(e.target.value)
              const firstInCh = verses.find(v => parseRef(v.verse_ref)?.chapter === ch)
              onChange(firstInCh?.verse_ref ?? '')
            }}
            className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-violet-300 bg-white"
          >
            {!value && <option value="">Ch</option>}
            {chapters.map(ch => (
              <option key={ch} value={ch}>{bookName} {ch}</option>
            ))}
          </select>
          <select
            value={value}
            onChange={e => onChange(e.target.value)}
            className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-violet-300 bg-white"
          >
            {!value && <option value="">v.</option>}
            {chVerses.map(v => {
              const p = parseRef(v.verse_ref)
              return <option key={v.verse_ref} value={v.verse_ref}>v.{p?.verse}</option>
            })}
          </select>
        </div>
      </div>
    )
  }

  const overlaps   = getOverlaps()
  const skipped    = uncoveredCount()
  const canSave    = sections.some(s => s.label.trim() && s.startVerse)

  return (
    <div className="flex flex-col gap-3 p-4">
      <div>
        <p className="text-sm font-semibold text-slate-700 mb-0.5">Define pericopes</p>
        <p className="text-xs text-slate-400">
          Name each section and set its verse range. Sections can overlap or skip verses — gaps are fine.
        </p>
      </div>

      {sections.length === 0 && (
        <div className="flex flex-col items-center justify-center py-8 border border-dashed border-slate-200 rounded-xl gap-2">
          <p className="text-xs text-slate-400">No sections yet</p>
          <button
            onClick={addSection}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-violet-600 text-white text-xs font-medium rounded-lg hover:bg-violet-700 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />Add pericope
          </button>
        </div>
      )}

      <div className="space-y-2">
        {sections.map((s) => {
          const hasOverlap = overlaps.has(s.id)
          return (
            <div key={s.id} className={`border rounded-xl px-3 py-2.5 bg-white transition-colors ${
              hasOverlap ? 'border-amber-300 bg-amber-50/40' : 'border-slate-200'
            }`}>
              <div className="flex items-start gap-2">
                {/* Label */}
                <div className="flex-1 min-w-0">
                  <input
                    className="w-full text-sm border-0 outline-none placeholder:text-slate-300 text-slate-800 bg-transparent"
                    placeholder="Section name (e.g. The Arrival)"
                    value={s.label}
                    autoFocus
                    onChange={e => updateSection(s.id, 'label', e.target.value)}
                  />
                  {hasOverlap && (
                    <p className="text-[10px] text-amber-600 font-medium mt-0.5 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />Overlaps with another section
                    </p>
                  )}
                </div>

                {/* Verse pickers */}
                <div className="flex items-end gap-2 shrink-0">
                  <VersePicker
                    label="From"
                    value={s.startVerse}
                    onChange={v => updateSection(s.id, 'startVerse', v)}
                  />
                  <span className="text-slate-300 text-xs pb-1.5">→</span>
                  <VersePicker
                    label="To"
                    value={s.endVerse}
                    onChange={v => updateSection(s.id, 'endVerse', v)}
                  />
                </div>

                <button onClick={() => removeSection(s.id)}
                  className="text-slate-300 hover:text-red-400 transition-colors mt-0.5 shrink-0">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )
        })}
      </div>

      {sections.length > 0 && (
        <div className="flex items-center gap-2">
          <button
            onClick={addSection}
            className="text-xs text-violet-600 hover:text-violet-800 flex items-center gap-1"
          >
            <Plus className="w-3 h-3" />Add pericope
          </button>
          {skipped > 0 && (
            <span className="text-[11px] text-slate-400 ml-1">
              {skipped} verse{skipped !== 1 ? 's' : ''} not covered — that's ok
            </span>
          )}
          <button
            onClick={handleSave}
            disabled={saving || !canSave}
            className="ml-auto text-xs bg-slate-900 text-white px-3 py-1.5 rounded-lg hover:bg-slate-700 disabled:opacity-40 flex items-center gap-1"
          >
            {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />}
            Save sections
          </button>
        </div>
      )}
    </div>
  )
}
