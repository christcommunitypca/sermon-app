'use client'

import { useState } from 'react'
import { Plus } from 'lucide-react'
import type { VerseNote } from '@/types/database'
import type { PendingItem } from './TeachingWorkspace'

const CATEGORIES = [
  { key: 'word_study',            label: 'Word Study',  color: 'text-blue-600',    bg: 'bg-blue-50',    border: 'border-blue-200'    },
  { key: 'cross_refs',            label: 'Cross-refs',  color: 'text-purple-600',  bg: 'bg-purple-50',  border: 'border-purple-200'  },
  { key: 'practical',             label: 'Analogies',   color: 'text-amber-600',   bg: 'bg-amber-50',   border: 'border-amber-200'   },
  { key: 'theology_by_tradition', label: 'Tradition',   color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-200' },
  { key: 'context',               label: 'Context',     color: 'text-orange-600',  bg: 'bg-orange-50',  border: 'border-orange-200'  },
  { key: 'application',           label: 'Application', color: 'text-rose-600',    bg: 'bg-rose-50',    border: 'border-rose-200'    },
] as const

type CategoryKey = typeof CATEGORIES[number]['key']
type Insights    = Record<string, Record<string, { title: string; content: string }[]>>

interface Props {
  insights:      Insights
  verseNotes:    Record<string, VerseNote[]>
  checkedItems:  Set<string>
  hiddenVerses:  Set<string>
  pendingItemId: string | null
  onPendingItem: (item: PendingItem) => void
}

export function OutlineReference({ insights, verseNotes, checkedItems, hiddenVerses, pendingItemId, onPendingItem }: Props) {
  const [activeTab,     setActiveTab]     = useState<CategoryKey | 'notes'>('notes')
  const [flagFilter,    setFlagFilter]    = useState<'all' | 'flagged' | 'unflagged'>('all')
  const [usedFilter,    setUsedFilter]    = useState<'all' | 'used' | 'unused'>('all')

  // All verse refs with any content
  const allVerseRefs = Array.from(new Set([
    ...Object.keys(verseNotes).filter(r => verseNotes[r].some(n => n.content.trim())),
    ...Object.keys(insights),
  ])).sort()

  const hasNotes    = allVerseRefs.some(r => verseNotes[r]?.some(n => n.content.trim()))
  const hasInsights = Object.keys(insights).length > 0

  if (!hasNotes && !hasInsights) {
    return (
      <div className="px-4 py-8 text-center text-xs text-slate-300">
        Add notes and generate research in the Verse by Verse view
      </div>
    )
  }

  const visibleRefs = allVerseRefs.filter(r => !hiddenVerses.has(r))


  function queue(srcId: string, content: string, type: PendingItem['type'], kind: 'note' | 'research') {
    onPendingItem({ content, type, sourceKind: kind, sourceId: srcId })
  }

  // Build tab list — only tabs with content
  const visibleTabs: (CategoryKey | 'notes')[] = []
  if (hasNotes) visibleTabs.push('notes')
  for (const cat of CATEGORIES) {
    if (Object.values(insights).some(cats => (cats[cat.key]?.length ?? 0) > 0)) visibleTabs.push(cat.key)
  }
  const effectiveTab = visibleTabs.includes(activeTab) ? activeTab : (visibleTabs[0] ?? 'notes')

  // Count flagged per tab for badge
  function flaggedCount(tab: CategoryKey | 'notes') {
    if (tab === 'notes') return Object.values(verseNotes).flat().filter(n => n.used_count > 0).length
    let n = 0
    for (const [ref, cats] of Object.entries(insights)) {
      ;(cats[tab] ?? []).forEach((_, i) => { if (checkedItems.has(`${ref}::${tab}::${i}`)) n++ })
    }
    return n
  }

  return (
    <div className="flex flex-col gap-2 min-h-0">

      {/* ── Tabs — VBV-style pills ─────────────────────────────────────────── */}
      <div className="flex flex-wrap gap-1.5">
        {visibleTabs.map(tab => {
          const cat      = CATEGORIES.find(c => c.key === tab)
          const isActive = tab === effectiveTab
          const flagged  = flaggedCount(tab)
          return (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors ${
                isActive
                  ? cat
                    ? `${cat.bg} ${cat.color} ring-1 ring-current`
                    : 'bg-slate-200 text-slate-800'
                  : cat
                    ? `${cat.bg} ${cat.color} opacity-60 hover:opacity-100`
                    : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
              }`}
            >
              {tab === 'notes' ? 'Notes' : cat?.label}
              {flagged > 0 && (
                <span className="ml-1 text-[10px] font-bold opacity-80">{flagged}</span>
              )}
            </button>
          )
        })}
      </div>

      {/* ── Filters ───────────────────────────────────────────────────────── */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="flex items-center gap-0.5 bg-slate-100 rounded-lg p-0.5">
          {(['all', 'flagged', 'unflagged'] as const).map(f => (
            <button key={f} onClick={() => setFlagFilter(f)}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                flagFilter === f ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-400 hover:text-slate-600'
              }`}>
              {f === 'all' ? 'All' : f === 'flagged' ? '✓ Flagged' : 'Unflagged'}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-0.5 bg-slate-100 rounded-lg p-0.5">
          {(['all', 'unused', 'used'] as const).map(f => (
            <button key={f} onClick={() => setUsedFilter(f)}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                usedFilter === f ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-400 hover:text-slate-600'
              }`}>
              {f === 'all' ? 'All' : f === 'used' ? 'Used' : 'Unused'}
            </button>
          ))}
        </div>
      </div>

      {/* ── Content ───────────────────────────────────────────────────────── */}
      <div className="space-y-4 overflow-y-auto pb-4">

        {/* Notes tab */}
        {effectiveTab === 'notes' && visibleRefs.map(ref => {
          const notes = (verseNotes[ref] ?? []).filter(n => {
            if (!n.content.trim()) return false
            if (flagFilter === 'flagged'   && n.used_count === 0) return false
            if (flagFilter === 'unflagged' && n.used_count  > 0) return false
            if (usedFilter === 'used'      && n.used_count === 0) return false
            if (usedFilter === 'unused'    && n.used_count  > 0) return false
            return true
          })
          if (!notes.length) return null
          return (
            <div key={ref}>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-2">{ref}</p>
              <div className="space-y-1.5">
                {notes.map(note => (
                  <div key={note.id} className="group relative flex items-start gap-2 rounded-lg px-2 py-1.5 hover:bg-slate-50">
                    <p className="flex-1 text-sm text-slate-600 leading-relaxed pr-10">{note.content}</p>
                    <div className="flex items-center gap-1 shrink-0 absolute right-1 top-1.5">
                      {note.used_count > 0 && (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 bg-violet-100 text-violet-500 rounded-full">
                          {note.used_count}×
                        </span>
                      )}
                      <button
                        onClick={() => queue(note.id, note.content, 'sub_point', 'note')}
                        className={`p-1.5 rounded-lg transition-all ${
                          pendingItemId === note.id
                            ? 'text-violet-600 bg-violet-100 opacity-100'
                            : 'text-slate-300 hover:text-slate-700 hover:bg-slate-100 opacity-0 group-hover:opacity-100'
                        }`}
                        title="Place in outline"
                      ><Plus className="w-3.5 h-3.5" /></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )
        })}

        {/* Research category tabs */}
        {effectiveTab !== 'notes' && (() => {
          const cat = CATEGORIES.find(c => c.key === effectiveTab)!
          return visibleRefs.map(ref => {
            const items = (insights[ref]?.[effectiveTab] ?? []).filter((_, i) => {
              const key       = `${ref}::${effectiveTab}::${i}`
              const isFlagged = checkedItems.has(key)
              if (flagFilter === 'flagged'   && !isFlagged) return false
              if (flagFilter === 'unflagged' &&  isFlagged) return false
              return true
            })
            if (!items.length) return null
            return (
              <div key={ref}>
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-2">{ref}</p>
                <div className="space-y-2">
                  {items.map((item, rawIdx) => {
                    // rawIdx here is post-filter; need original index for key lookup
                    const origIdx   = (insights[ref]?.[effectiveTab] ?? []).indexOf(item)
                    const itemKey   = `${ref}::${effectiveTab}::${origIdx}`
                    const isFlagged = checkedItems.has(itemKey)
                    return (
                      <div key={origIdx} className={`group relative border-l-2 pl-3 rounded-r-lg py-1 transition-colors ${
                        isFlagged ? `${cat.border} ${cat.bg}` : 'border-slate-100 hover:border-slate-200'
                      }`}>
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            {item.title && (
                              effectiveTab === 'word_study'
                                ? <WordStudyTitle title={item.title} />
                                : <span className="text-xs font-semibold text-slate-700 block mb-0.5">{item.title}</span>
                            )}
                            <p className="text-sm text-slate-600 leading-relaxed">{item.content}</p>
                          </div>
                          <div className="flex items-center gap-1 shrink-0 ml-2">
                            {isFlagged && (
                              <span className={`text-[11px] font-bold px-1.5 py-0.5 rounded-full ${cat.bg} ${cat.color}`}>✓</span>
                            )}
                            <button
                              onClick={() => {
                                const type: PendingItem['type'] =
                                  effectiveTab === 'application' ? 'application'
                                  : effectiveTab === 'practical' ? 'illustration'
                                  : 'sub_point'
                                const content = item.title ? `${item.title} — ${item.content}` : item.content
                                queue(`${ref}-${effectiveTab}-${origIdx}`, content, type, 'research')
                              }}
                              className={`p-1.5 rounded-lg transition-all opacity-0 group-hover:opacity-100 ${
                                pendingItemId === `${ref}-${effectiveTab}-${origIdx}`
                                  ? 'text-violet-600 bg-violet-100 opacity-100'
                                  : 'text-slate-300 hover:text-slate-700 hover:bg-slate-100'
                              }`}
                              title="Place in outline"
                            ><Plus className="w-3.5 h-3.5" /></button>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            )
          })
        })()}
      </div>
    </div>
  )
}

function WordStudyTitle({ title }: { title: string }) {
  const match = title.match(/^(.+?)\s+\((.+)\)$/)
  if (!match) return <span className="text-xs font-semibold text-slate-700 block mb-0.5">{title}</span>
  const [, original, transliteration] = match
  return (
    <span className="flex items-baseline gap-1.5 mb-0.5">
      <span className="text-sm font-bold text-slate-800">{original}</span>
      <span className="text-xs text-slate-500 italic">{transliteration}</span>
    </span>
  )
}
