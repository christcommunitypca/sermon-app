'use client'

import { useState, useCallback } from 'react'
import { VerseByVersePanel } from './VerseByVersePanel'
import { OutlinePanel } from './OutlinePanel'
import type { OutlineBlock, VerseNote } from '@/types/database'
import type { VerseData } from '@/lib/esv'

// ── Pending placement ─────────────────────────────────────────────────────────
// When the teacher taps + on a note or research item, it enters pending state.
// The outline shows drop zones; tapping one places the item there.
export interface PendingItem {
  content:    string
  type:       OutlineBlock['type']
  sourceKind: 'note' | 'research'
  sourceId:   string   // verse note id or research item id
}

export type TeachingMode = 'verse_by_verse' | 'outline'

type Insights = Record<string, Record<string, { title: string; content: string }[]>>

interface Props {
  sessionId:         string
  churchId:          string
  churchSlug:        string
  outlineId:         string
  initialBlocks:     OutlineBlock[]
  flowStructure?:    { type: string; label: string }[]
  hasValidAIKey:     boolean
  scriptureRef:      string | null
  initialMode:       TeachingMode
  estimatedDuration: number | null
  initialVerses:     VerseData[] | null
  initialInsights:   Insights
  initialVerseNotes: Record<string, VerseNote[]>
}

export function TeachingWorkspace({
  sessionId, churchId, churchSlug, outlineId,
  initialBlocks, flowStructure, hasValidAIKey,
  scriptureRef, estimatedDuration,
  initialVerses, initialInsights, initialVerseNotes,
}: Props) {
  const [verses,      setVerses]      = useState<VerseData[] | null>(initialVerses)
  const [insights,    setInsights]    = useState<Insights>(initialInsights)
  const [verseNotes,  setVerseNotes]  = useState<Record<string, VerseNote[]>>(initialVerseNotes)
  const [blocks,      setBlocks]      = useState<OutlineBlock[]>(initialBlocks)
  const [pending,     setPending]     = useState<PendingItem | null>(null)

  // When VBV generates an outline, inject blocks
  const handleOutlineGenerated = useCallback((newBlocks: OutlineBlock[]) => {
    setBlocks(newBlocks)
  }, [])

  // Called from OutlinePanel when a pending item is placed (to increment used_count)
  const handleItemPlaced = useCallback((item: PendingItem) => {
    if (item.sourceKind === 'note') {
      setVerseNotes(prev => {
        const next = { ...prev }
        for (const ref of Object.keys(next)) {
          next[ref] = next[ref].map(n =>
            n.id === item.sourceId ? { ...n, used_count: n.used_count + 1 } : n
          )
        }
        return next
      })
    }
    setPending(null)
  }, [])

  return (
    <div className="flex gap-0 min-h-[600px] -mx-4 px-0 sm:mx-0 sm:px-0">

      {/* ── Left: Verse by Verse ───────────────────────────────────────────── */}
      <div className="w-[45%] min-w-0 border-r border-slate-100 pr-4 overflow-y-auto">
        <VerseByVersePanel
          sessionId={sessionId}
          churchId={churchId}
          scriptureRef={scriptureRef}
          hasValidAIKey={hasValidAIKey}
          flowStructure={flowStructure}
          estimatedDuration={estimatedDuration}
          verses={verses}
          insights={insights}
          verseNotes={verseNotes}
          onVersesChange={setVerses}
          onInsightsChange={setInsights}
          onVerseNotesChange={setVerseNotes}
          onOutlineGenerated={handleOutlineGenerated}
          onPendingItem={setPending}
          pendingItemId={pending?.sourceId ?? null}
        />
      </div>

      {/* ── Right: Outline ─────────────────────────────────────────────────── */}
      <div className="flex-1 min-w-0 pl-4 overflow-y-auto">
        <OutlinePanel
          sessionId={sessionId}
          churchId={churchId}
          churchSlug={churchSlug}
          outlineId={outlineId}
          initialBlocks={blocks}
          flowStructure={flowStructure}
          hasValidAIKey={hasValidAIKey}
          estimatedDuration={estimatedDuration}
          initialInsights={insights}
          initialVerseNotes={verseNotes}
          pending={pending}
          onItemPlaced={handleItemPlaced}
          onPendingFromRef={setPending}
          onCancelPending={() => setPending(null)}
        />
      </div>

      {/* ── Pending placement banner ───────────────────────────────────────── */}
      {pending && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50
          flex items-center gap-3 px-4 py-3
          bg-violet-700 text-white text-sm font-medium rounded-2xl shadow-xl
          pointer-events-none select-none">
          <span className="w-2 h-2 rounded-full bg-violet-300 animate-pulse shrink-0" />
          Tap a drop zone in the outline to place
          <button
            onClick={() => setPending(null)}
            className="pointer-events-auto ml-1 text-violet-300 hover:text-white transition-colors text-xs underline"
          >
            Cancel
          </button>
        </div>
      )}
    </div>
  )
}
